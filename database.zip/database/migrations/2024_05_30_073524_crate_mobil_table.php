<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CrateMobilTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create("mobil", function (Blueprint $table) {  
            $table->bigIncrements('id'); //Primary Key
            $table->string('kategori', 50);
            $table->string('nama', 50);
            $table->string('merek', 50);
            $table->string('tahun', 4);
            $table->string('harga', 15);
            $table->string('poster', 50);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mobil');
    }
}
