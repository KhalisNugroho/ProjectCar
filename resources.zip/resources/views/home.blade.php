@extends('layouts/main')
@section('title', 'home')
@section('artikel')
    <h1>HOME</h1>
    <p>Selamat Datang di Web Jual Beli Mobil.</p>
@endsection