<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mobil;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

class PageController extends Controller
{
    public function home()
    {
        return view("home", ["key" => "home"]);
    }

    public function messages()
    {
        return view("messages", ["key" => "messages"]);
    }

    public function car()
    {
        $car = Mobil::orderBy('id', 'desc')->get();
        return view("car", ["key" => "car", "mv"=> $car]);
    }

    public function addformcar()
    {
        return view("form-add", ["key" => "car"]);
    }

    public function savecar(Request $request)
    {
        $file_name = time().'-'.$request->file('poster')->getClientOriginalName();
        // return $file_name;
        $path = $request->file('poster')->storeAs('poster', $file_name,'public');

        Mobil::create([
            'kategori'     => $request->kategori,
            'nama'     => $request->nama,
            'merek'      => $request->merek,
            'tahun'    => $request->tahun,
            'harga'      => $request->harga,
            'poster'    => $path
        ]);
        return redirect('/car')->with('alert', 'Data Berhasil Disimpan');
    }

    public function editformcar($id)
    {
        $car = Mobil::find($id);
        return view('form-edit', [
            "key" => "car",
            'mv' => $car
        ]);
    }

    public function updatecar(Request $request, $id)
    {
        $car = Mobil::find($id);

        $car->kategori = $request->kategori;
        $car->nama = $request->nama;
        $car->merek = $request->merek;
        $car->tahun = $request->tahun;
        $car->harga = $request->harga;
        if ($request->poster)
        {
            if($car->poster)
            {
                Storage::disk('public')->delete($car->poster);
            }
            $file_name = time().'-'.$request->file('poster')->getClientOriginalName(); //mengubah nama file
            $path = $request->file('poster')->storeAs('poster', $file_name,'public'); //simpan file ke folder public
            $car->poster=$path; //simpan path ke database
        }
        $car->save(); //simpan data
        return redirect('/car')->with('alert', 'Data Berhasil Diupdate');
    }

    public function deletecar($id)
    {
        $car = Mobil::find($id);
        if($car->poster)
        {
            Storage::disk('public')->delete($car->poster);
        }
        $car->delete();
        return redirect('/car')->with('alert', 'Data Berhasil Dihapus');
    }

    public function login()
    {
        return view("login");
    }

    public function formedituser(){
        return view("formedituser", ["key"=>"edit_user"]);
    }

    public function updateuser(Request $request){
        if($request->password_baru == $request->konfirmasi_password){
            $user = Auth::user();
            $user -> password = bcrypt($request -> password_baru);
            $user -> save();
            return redirect("/user")->with("info", "Password Berhasil Diubah");
        }
        else{
            return redirect("/user")->with("info", "Password Gagal Diubah");
        }
    }
}
