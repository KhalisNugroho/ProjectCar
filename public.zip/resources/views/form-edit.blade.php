@extends('layouts.main')
@section('title', 'Form Edit Car')
@section('artikel')
    <div class="card">
        <div class="card-head"></div>
        <div class="card-body">
            <!--Form Add Car Disini-->
            <form action="/update/{{$mv->id}}" method="post" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="form-group">
                        <label>Kategori Mobil</label>
                        <select name="kategori" class="form-control">
                            <option value="0"> --Pilih Kategori-- </option>
                            <option value="Sport" {{($mv->kategori=="Sport") ? "selected":""}}>Sport</option>
                            <option value="SUV" {{($mv->kategori=="SUV") ? "selected":""}}>SUV</option>
                            <option value="Sedan" {{($mv->kategori=="Sedan") ? "selected":""}}>Sedan</option>
                            <option value="Hybrid" {{($mv->kategori=="Hybrid") ? "selected":""}}>Hybrid</option>
                            <option value="SUB" {{($mv->kategori=="SUB") ? "selected":""}}>SUB</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nama Mobil</label>
                        <input type="text" name="nama" class="form-control" value="{{$mv->nama}}" required>
                    </div>
                    <div class="form-group">
                        <label>Merek</label>
                        <select name="merek" class="form-control">
                            <option value="0"> --Pilih Merek-- </option>
                            <option value="Toyota" {{($mv->merek=="Toyota") ? "selected":""}}>Toyota</option>
                            <option value="Daihatzu" {{($mv->merek=="Daihatzu") ? "selected":""}}>Daihatzu</option>
                            <option value="Mitsubisi" {{($mv->merek=="Mitsubisi") ? "selected":""}}>Mitsubisi</option>
                            <option value="Honda"{{($mv->merek=="Honda") ? "selected":""}}>Honda</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tahun</label>
                        <input type="number" min="1900" max="2100" name="tahun" class="form-control" value="{{$mv->tahun}}" readonly required>
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input type="number" name="harga" class="form-control" value="{{ $mv->harga}}" required>
                    </div>
                    <div class="form-group">
                        <label>Poster</label>
                        <input type="file" name="poster" class="form-control-file" accept="image/*" value="{{$mv->poster}}">
                    </div>
                    <label></label>
                    <div class="from-group">
                        @if ($mv->poster)
                            <img src="{{ asset('/storage/'.$mv->poster) }}"  
                            alt = "{{ $mv->poster}}" height="80" width="120">
                            @else
                            <img src="/storage/poster/no-image.png"
                            alt = "No Image" height="80" width="120">
                        @endif
                    </div>
                    <label></label>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">SIMPAN</button>
                    </div>
            </form>
        </div>
    </div>
@endsection