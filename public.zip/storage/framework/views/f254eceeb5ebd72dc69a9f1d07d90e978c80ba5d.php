    <?php $__env->startSection('title', 'Form Add Car'); ?>
    <?php $__env->startSection('artikel'); ?>
        <div class="card">
            <div class="card-head"></div>
            <div class="card-body">
                <!--Form Add Car Disini-->
                <form action="/save" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Kategori Mobil</label>
                        <select name="kategori">
                            <option value="0"> --Pilih Kategori-- </option>
                            <option value="Sport">Sport</option>
                            <option value="SUV">SUV</option>
                            <option value="Sedan">Sedan</option>
                            <option value="Hybrid">Hybrid</option>
                            <option value="SUB">SUB</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nama Mobil</label>
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Merek</label>
                        <select name="merek">
                            <option value="0"> --Pilih Merek-- </option>
                            <option value="Toyota">Toyota</option>
                            <option value="Daihatzu">Daihatzu</option>
                            <option value="Mitsubisi">Mitsubisi Turbo</option>
                            <option value="Honda">Honda</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tahun</label>
                        <input type="number" min="1900" max="2100" name="tahun" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input type="number" name="harga" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Poster</label>
                        <input type="file" name="poster" class="form-control-file" accept="image/*">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">SIMPAN</button>
                    </div>
                </form>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\Aplication Car\resources\views/form-add.blade.php ENDPATH**/ ?>