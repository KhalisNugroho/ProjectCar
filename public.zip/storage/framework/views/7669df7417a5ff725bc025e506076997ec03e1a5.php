<?php $__env->startSection('title', 'Form Edit Movies'); ?>
<?php $__env->startSection('artikel'); ?>
    <div class="card">
        <div class="card-head"></div>
        <div class="card-body">
            <!--Form Add Movies Disini-->
            <form action="/update/<?php echo e($mv->id); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($mv->title); ?>" required>
                </div>
                <div class="form-group">
                    <label>Genre</label>
                    <select name="genre" class="form-control">
                        <option value="0"> --Pilih Genre-- </option>
                        <option value="Action" <?php echo e(($mv->genre == 'Action') ? 'selected' : ''); ?>>Action</option>
                        <option value="Horror" <?php echo e(($mv->genre == 'Horror') ? 'selected' : ''); ?>>Horror</option>
                        <option value="Comedy" <?php echo e(($mv->genre == 'Comedy') ? 'selected' : ''); ?>>Comedy</option>
                        <option value="Anime" <?php echo e(($mv->genre == 'Anime') ? 'selected' : ''); ?>>Anime</option>
                        <option value="Thriller" <?php echo e(($mv->genre == 'Thriller') ? 'selected' : ''); ?>>Thriller</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Year</label>
                    <input type="number" min="1900" max="2100" name="year" class="form-control" value="<?php echo e($mv->year); ?>" readonly required>
                </div>
                <div class="form-group">
                    <label>Poster</label>
                    <input type="file" name="poster" class="form-control-file" accept="image/*" value="<?php echo e($mv->poster); ?>">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">SIMPAN</button>
                </div>
                <div class="form-control">
                    <img src="<?php echo e(asset('/storage/'.$mv->poster)); ?>"
                    alt = "<?php echo e($mv->poster); ?>" heigh="80" width="80">
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebMovies\resources\views/layouts/form-edit.blade.php ENDPATH**/ ?>