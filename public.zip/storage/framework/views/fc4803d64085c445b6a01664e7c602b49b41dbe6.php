<?php $__env->startSection('title', 'Form Edit Car'); ?>
<?php $__env->startSection('artikel'); ?>
    <div class="card">
        <div class="card-head"></div>
        <div class="card-body">
            <!--Form Add Car Disini-->
            <form action="/update/<?php echo e($mv->id); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                        <label>Kategori Mobil</label>
                        <select name="kategori" class="form-control">
                            <option value="0"> --Pilih Kategori-- </option>
                            <option value="Sport" <?php echo e(($mv->kategori=="Sport") ? "selected":""); ?>>Sport</option>
                            <option value="SUV" <?php echo e(($mv->kategori=="SUV") ? "selected":""); ?>>SUV</option>
                            <option value="Sedan" <?php echo e(($mv->kategori=="Sedan") ? "selected":""); ?>>Sedan</option>
                            <option value="Hybrid" <?php echo e(($mv->kategori=="Hybrid") ? "selected":""); ?>>Hybrid</option>
                            <option value="SUB" <?php echo e(($mv->kategori=="SUB") ? "selected":""); ?>>SUB</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nama Mobil</label>
                        <input type="text" name="nama" class="form-control" value="<?php echo e($mv->nama); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Merek</label>
                        <select name="merek" class="form-control">
                            <option value="0"> --Pilih Merek-- </option>
                            <option value="Toyota" <?php echo e(($mv->merek=="Toyota") ? "selected":""); ?>>Toyota</option>
                            <option value="Daihatzu" <?php echo e(($mv->merek=="Daihatzu") ? "selected":""); ?>>Daihatzu</option>
                            <option value="Mitsubisi" <?php echo e(($mv->merek=="Mitsubisi") ? "selected":""); ?>>Mitsubisi</option>
                            <option value="Honda"<?php echo e(($mv->merek=="Honda") ? "selected":""); ?>>Honda</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tahun</label>
                        <input type="number" min="1900" max="2100" name="tahun" class="form-control" value="<?php echo e($mv->tahun); ?>" readonly required>
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input type="number" name="harga" class="form-control" value="<?php echo e($mv->harga); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Poster</label>
                        <input type="file" name="poster" class="form-control-file" accept="image/*" value="<?php echo e($mv->poster); ?>">
                    </div>
                    <label></label>
                    <div class="from-group">
                        <?php if($mv->poster): ?>
                            <img src="<?php echo e(asset('/storage/'.$mv->poster)); ?>"  
                            alt = "<?php echo e($mv->poster); ?>" height="80" width="120">
                            <?php else: ?>
                            <img src="/storage/poster/no-image.png"
                            alt = "No Image" height="80" width="120">
                        <?php endif; ?>
                    </div>
                    <label></label>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">SIMPAN</button>
                    </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\Aplication Car\resources\views/form-edit.blade.php ENDPATH**/ ?>