<?php $__env->startSection('title', 'settings'); ?>
<?php $__env->startSection('artikel'); ?>
    <h1>Settings</h1>
    <p>Ini adalah halaman settings</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\WebMovies\resources\views/layouts/settings.blade.php ENDPATH**/ ?>