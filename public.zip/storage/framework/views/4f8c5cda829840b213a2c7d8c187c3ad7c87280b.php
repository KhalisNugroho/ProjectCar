<?php $__env->startSection('title', 'movies'); ?>
<?php $__env->startSection('artikel'); ?>
    <div class="card">
        <div class="card-header"></div>
            <a href="movies/add-form" class="btn btn-primary"><i class="bi bi-plus-square"></i>Movies</a>
        <div class="card-body">
            <?php if(session('alert')): ?>
                <strong><?php echo e(session('altert')); ?></strong>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('alert')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
            <?php endif; ?>
            <!--Tabel Disini-->
            <table id="example" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Title</th>
                        <th>Genre</th>
                        <th>Year</th>
                        <th>Poster</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $mv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx =>$m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($idx+1); ?></td>
                            <td><?php echo e($m->title); ?></td>
                            <td><?php echo e($m->genre); ?></td>
                            <td><?php echo e($m->year); ?></td>
                            <td>
                                <img src="<?php echo e(asset('/storage/'.$m->poster)); ?>"
                                alt = "<?php echo e($m->poster); ?>" heigh="80" width="80">
                            </td>
                            <td>
                                <a href="/movies/edit-form<?php echo e($m->id); ?>" class="btn btn-success"><i class="bi bi-pencil-square"></i></a>
                                <a href="/delete/<?php echo e($m->id); ?>" class="btn btn-danger"><i class="bi bi-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebMovies\resources\views/layouts/movies.blade.php ENDPATH**/ ?>