<?php $__env->startSection('title', 'home'); ?>
<?php $__env->startSection('artikel'); ?>
    <h1>HOME</h1>
    <p>Selamat Datang di Web Jual Beli Mobil.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\Aplication Car\resources\views/home.blade.php ENDPATH**/ ?>