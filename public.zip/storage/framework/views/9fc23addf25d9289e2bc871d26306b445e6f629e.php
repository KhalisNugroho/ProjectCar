<?php $__env->startSection('title', 'Form Add Movies'); ?>
<?php $__env->startSection('artikel'); ?>
    <div class="card bg-dark text-white">
        <div class="card-head">
            <h1 class="text-center mt-3">Add New Movie</h1>
        </div>
        <div class="card-body">
            <!--Form Add Movies Here-->
            <form action="/save" method="post" enctype="multipart/form-data" class="p-3">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="title" class="font-weight-bold">Title</label>
                    <input type="text" id="title" name="title" class="form-control" placeholder="Enter movie title" required>
                </div>
                <div class="form-group">
                    <label for="genre" class="font-weight-bold">Genre</label>
                    <select id="genre" name="genre" class="form-control">
                        <option value="0"> --Select Genre-- </option>
                        <option value="Action">Action</option>
                        <option value="Horror">Horror</option>
                        <option value="Comedy">Comedy</option>
                        <option value="Anime">Anime</option>
                        <option value="Thriller">Thriller</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="year" class="font-weight-bold">Year</label>
                    <input type="number" id="year" min="1900" max="2100" name="year" class="form-control" placeholder="Enter release year" required>
                </div>
                <div class="form-group">
                    <label for="poster" class="font-weight-bold">Poster</label>
                    <input type="file" id="poster" name="poster" class="form-control-file" accept="image/*" required>
                </div>
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-primary btn-lg">Save Movie</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebMovies\resources\views/form-add.blade.php ENDPATH**/ ?>